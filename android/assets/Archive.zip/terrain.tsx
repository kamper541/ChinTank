<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="terrain" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="224" columns="14">
 <image source="../../../../Downloads/fantasyhextiles_v3.png" width="256" height="288"/>
</tileset>
