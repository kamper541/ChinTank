<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="Ground" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="784" columns="28">
 <image source="Pack01/RPG Maker (Vx Ace)/TileB.png" width="512" height="512"/>
</tileset>
